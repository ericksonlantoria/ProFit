import { LightningElement, api, track, wire } from "lwc";
import upcomingEvents from "@salesforce/apex/AttendeeEventService.upcomingEvents";
import pastEvents from "@salesforce/apex/AttendeeEventService.pastEvents";

export default class AttendeeEvents extends LightningElement {
    @api recordId;
    @track eventCol = [{
        label: 'Event Name',
        fieldName: 'Name',
        type: 'text',
        sortable: true
    },
    {
        label: 'Start Date and Time',
        fieldName: 'Start_Date_Time__c',
        type: 'date',
        typeAttributes: {
            weekday: 'long',
            day: 'numeric',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        }
    },
    {
        label: 'End Date and Time',
        fieldName: 'End_Date_Time__c',
        type: 'date',
        typeAttributes: {
            weekday: 'long',
            day: 'numeric',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        }
    }];

    @track error;
    @track upcomingEventsList;
    @wire(upcomingEvents, {attendeeId : '$recordId'})
    wiredUpcomingEvents({error,data}){
        if(data){
        this.upcomingEventsList = data;
        }else if(error){
        this.error = error;
        }
    }

    @track pastEventsList;
    @wire(pastEvents, {attendeeId : '$recordId'})
    wiredPastEvents({error,data}){
        if(data){
        this.pastEventsList = data;
        }else if(error){
        this.error = error;
        }
    }
}